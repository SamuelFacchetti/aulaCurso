<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
	<title>Meu Primeiro Site!</title>
</head>
<body>
	<form action="adicionar.php" method="post">
		<h1>Cadastro</h1>

		<input placeholder="Insira seu nome" type="text" name="nome" id="">
		<input placeholder="Digite seu email" type="email" name="email" id="">
		<input placeholder="Crie uma senha" type="password" name="senha" id="">

		<button type="submit">Cadastrar</button>
	</form>

	<div class="conteudo">
		<?php
		
			require "conectar.php";

			function listar() {
				$sql = "SELECT * FROM dados";

				$resul = mysqli_query(conn(), $sql);

				$data = array();
				while ($linha_tabela = mysqli_fetch_assoc($resul)){
					$data[]= $linha_tabela;
				}

				return $data;
			}


			$dados = listar();

			foreach ($dados as $dado):?>
				<p><?=$dado['nome']?></p>
		<?php
			endforeach;
		?>

	</div>
</body>
</html>