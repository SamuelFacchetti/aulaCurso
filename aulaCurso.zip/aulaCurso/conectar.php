<?php

function conn() {
	$conn = mysqli_connect("localhost", "root", "", "banco");

	return $conn;
}
