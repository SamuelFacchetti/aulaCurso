<?php

require_once "conectar.php";

$id = $_GET['id'];
$comando = "SELECT * FROM dados WHERE id = '$id'";
$resultado = mysqli_query(conn(), $comando);
$variavel = mysqli_fetch_assoc($resultado);

?>

<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver id: <?=$variavel['id']?></title>
</head>
<body>
    <h1><?=$variavel['nome']?></h1>
    <h3><?=$variavel['id']?></h3>
    <p><?=$variavel['email']?></p>
    <a href="index.php">Voltar</a>
</body>
</html>