cd mysql/bin

mysql -u root -p

CREATE DATABASE banco;

USE banco;

CREATE TABLE dados (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	nome VARCHAR(100) NOT NULL,
	email VARCHAR(100) NOT NULL,
	senha VARCHAR(100) NOT NULL
);


SELECT * FROM dados;
